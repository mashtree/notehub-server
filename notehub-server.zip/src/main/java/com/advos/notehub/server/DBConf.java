/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.advos.notehub.server;

/**
 *
 * @author triyono
 */
public class DBConf {
    public static String db_host = "localhost";
    
    public static int db_port = 3306;
    
    public static String db_name = "notehub";
    
    public static String db_user = "root";
    
    public static String db_pass = "";
}
